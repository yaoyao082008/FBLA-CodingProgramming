import firebase_admin
from firebase_admin import firestore, credentials
import datetime

# Application Default credentials are automatically created.
creds = credentials.Certificate({
  "type": "service_account",
  "project_id": "fbla-financial",
  "private_key_id": "fe2ec3521222f9f803fc1156803d2ecc9556111c",
  "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDD71V2XUfmLjtV\nfN3xWTQXAN5bI8US5OtDrEQ3RIVG1z2Sr1YdY3TJnFLAIU3mOJioC13zGQluTcz4\n5uKLO7V0m4pzGJ29Ny8cSXmTkcfz7hZg6ONzIVVaC1BGzGZVrv6g+41iIC/hq1Jl\nhXvD3dOnrNBLsv0RQfTR1/z680Ely2ny6EX+J2pqBsGJgIPjTY91qa39ACl93p4j\nkKQHluyYQPzwj7WvzJeL9axYoLYByoF64BId+F0+VzVvzEBHMBk5XbLMohl67jz8\nJ13U87GIlICGQeVDcFGSz8VH/Mq7CY58sPCzhbWkbBeHWI8n/eJCnfNuJF2O9u1x\nnDbDzhbhAgMBAAECggEAX1GPD4KoyDukhN22sUOWujwjcE4yAROZunXTR9nPRpvO\nqg4fhDOOrMgeX7a0CXRuG45QGcQL2PwDY/Eas+aLy5shmwWWM2dlxUqfWSGaFzqz\n61hQ0oEcXy5S0uZ8QGHeIN3PtbV35b6tWpM6FxrS7Wb+fF0qjRs7qVx8h28Qufvk\nuk0BFAJNhsHmEkRDPU4nllz8IB2DqJnNLux+5rMZ3KTn9NGMn9inbIfL5hgpN9go\nKJuq4o0IPMVxkTdkIP9whe8Kj30t+JnRakMoE/Y6CH9RbNshcysFWsaFtMf/O+2E\nVpPgQqvWLDu8EEQPeBufr9XJzOMS0JhoRuvomLHPUwKBgQD5PHo3xrh51Zyy+sgg\nJy9xR6UdCmzDcNQcoPwoyexhCDggxsGEzgJ9m3J4piwJtyg6RLZhvkk6QbOjw5wP\njQ1EkxqOEKCekokyKF4jjMA0z3M1NT9rWoRzs+8H0duzlzlb8RVpgsE8jId0vcx4\nTwcnM8nWC3mdSX83kHqY3YUB+wKBgQDJQI4jZ/8jD4TXMFng5dsSk7b1EwzGLMtA\nWVjgPf/YjB9B6DdwF0aPZr2pQfRFYrktoKSqIQv6sUbamFf9Xg2rNddJmf2vvlmZ\no5eu2mZGEpyfqSci6XnCb31oUYFR0ekYQIWpPThtlBgJyyPcU8k5qcL8n6wIvn6G\nRiQGhuNP0wKBgFIiEPCihxZ3Q41jwWF/KE4/WvUoA1Ggs/W/Q3m5mTEcwUpj1VAL\nh5yXBnEl6atF9XbGQAgT6hPNpQJZqushA3dOttiMODIpfhbOYL98WbbNilzFcGHT\nUYTDjgjYqnsTYa6f0vuTQFTQxq69AU3AVU4g7emgnHItz0OjVBNeJL/TAoGAOszN\nurKL7OZ/3Y+W8wq1czwNXJVwSgaUa/yu5vW2ZsKp70u1xt5GE2flSiqnAA7UI+yn\nr71wDpL1LLEOJEzymW9ls292m352F1mg28mb0CVn9Y4qjRzCInkInw4RRqKaBCf1\n5Xipn/qA+3uKwrkINfzPp5fPX86okPq1U+LdT1kCgYEA1+Jp+O6VhRvB+CtleS5I\nrDsXuLqBX568evsm6WjUZVFvwmDVeaOcBzezp1nUB7lgZfC5UViI2C3FFeP5XkV6\nYTiox/f693HZ390/sVNNipUHwpkgSdyFZjAONLANiZQtvQ+Abo2dQdExasKZtDsj\nxGUuGjk1XE3ANpd2imP3gMs=\n-----END PRIVATE KEY-----\n",
  "client_email": "firebase-adminsdk-4x4hb@fbla-financial.iam.gserviceaccount.com",
  "client_id": "102456473024789919144",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-4x4hb%40fbla-financial.iam.gserviceaccount.com",
  "universe_domain": "googleapis.com"
})
app = firebase_admin.initialize_app(creds)
db = firestore.client()

current_year = int(datetime.datetime.today().strftime("%Y"))

# get user from database
def get_user(email, name=None):
    ref = db.collection("users").stream()
    for usr in ref:
        usr = usr.to_dict()
        try:
            if usr["email"] == email:
                return usr # return user if exists
        except Exception as e:
            pass      
    return new_user(email, name)

def new_user(email, name):
    ref = db.collection("users").document(email)

    data = {
        "email": email,
        "name": name,
        "incomes": [],
        "expenses": [],
        "balance": 0,
        "months": [0 for i in range(12)],
        "income_types": {"Cash": 0, "Check": 0, "Wire": 0},
        "expense_types": {"Cash": 0, "Check": 0, "Wire": 0}
        }

    ref.set(data)
    return data

def update_incomes(email, incomes):
    #name, type, amt, date
    ref = db.collection("users").document(email)
    data = {}
    types = {"Cash": 0, "Check": 0, "Wire": 0}
    print(types)
    for income in incomes:
        data[incomes[income][0]] = {
            'type': incomes[income][1],
            'amt': incomes[income][2],
            'date': incomes[income][3]
            }
        types[incomes[income][1]] += 1

    
    ref.update({"incomes": data, "income_types": types})
    

def update_expenses(email, expenses):
    #name, type, amt, date
    ref = db.collection("users").document(email)
    data = {}
    types = {"Cash": 0, "Check": 0, "Wire": 0}
    for expense in expenses:
        data[expenses[expense][0]]=  {
            'type': expenses[expense][1],
            'amt': expenses[expense][2],
            'date': expenses[expense][3]
            }
        types[expenses[expense][1]] += 1
            
    ref.update({"expenses": data, "expense_types": types})
    

def update_balance(email):
    ref = db.collection("users").document(email)
    usr = get_user(email)
    total_income = 0
    incomes = usr['incomes']

    months = [0 for i in range(12)]
    #finds total income
    for i in incomes:
        curr_amount = float(incomes[i]["amt"])
        total_income += curr_amount

        #dates incomes by month
        date = [int(d) for d in incomes[i]["date"].split("-")]
        if date[0] == current_year:
            months[date[1]-1] += curr_amount
    
        
    expenses = usr['expenses']
    total_expense = 0
    #finds total expenses
    for i in expenses:
        curr_amount = float(expenses[i]["amt"])
        total_income -= curr_amount
        
        #dates expenses by month
        date = [int(d) for d in expenses[i]["date"].split("-")]
        if date[0] == current_year:
            months[date[1]-1] -= curr_amount
    

    bal = total_expense + total_income

    data = {
        "balance": bal,
        "months": months
        }

    ref.update(data)
